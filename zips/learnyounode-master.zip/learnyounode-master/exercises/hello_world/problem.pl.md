Napisz program wypisujący napis "HELLO WORLD" na konsolę (stdout).

----------------------------------------------------------------------
## WSKAZÓWKI

Aby stworzyć program w Node.js, utwórz nowy plik z rozszerzeniem `.js` i zacznij pisać JavaScript! Wykonaj program uruchamiając go poleceniem
`node`. np.:

```sh
$ node program.js
```

Możesz wypisywać na konsolę tak samo jak w przeglądarce:

```js
console.log("text")
```

Kiedy skończysz, uruchom:

```sh
$ {appname} verify program.js
```

aby kontynuować. Twój program zostanie przetestowany, zobaczysz raport, a lekcja będzie oznaczone jako 'ukończona' gdy Ci się uda.
