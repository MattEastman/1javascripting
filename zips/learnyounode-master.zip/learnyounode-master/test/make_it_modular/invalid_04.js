// Triggers: fail.mod.missing_callback
require('./module_invalid_03')
