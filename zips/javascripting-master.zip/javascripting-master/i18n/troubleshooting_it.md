---
# Uh-oh, qualcosa non ha funzionato.
# Niente panico!  
---

## Verifica la tua soluzione:

`Soluzione
===================`

%solution%

`Il tuo tentativo
===================`

%attempt%

`Differenza
===================`

%diff%

## Risoluzione dei problemi:
 * Hai scritto correttamente il nome del file? Puoi verificare eseguendo il comando ls `%filename%`; se ti viene risposto ls: cannot access `%filename%`: No such file or directory allora devi creare un nuovo file o rinominare il file esistente, o cambiare la directory di lavoro con quella contenente il file.
 * Assicurati di non aver omesso delle parentesi, altrimenti l'interprete potrebbe incontrare errori nell'eseguirlo
 * Assicurati di non aver commesso errori nel comando stesso
