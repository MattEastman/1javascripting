__需要幫助？__ 查看本教學的 README 文件：https://github.com/workshopper/javascripting
