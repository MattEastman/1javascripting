__Besoin d'aide ?__ Voir le README pour cet atelier: https://github.com/workshopper/javascripting
