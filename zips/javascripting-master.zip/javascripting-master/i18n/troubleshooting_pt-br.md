---
# Opa! Parece que algo não está funcionando.
# Mas não se desespere!
---

## Verifique a solução:

`Solução
===================`

%solution%

`Sua tentativa
===================`

%attempt%

`Diferença
===================`

%diff%

## Solução de problemas adicionais:
 * Você digitou o nome do arquivo corretamente? Certifique-se de que o nome do arquivo é `%filename%`.
 * Verifique se você não se esqueceu dos parênteses, já que de outra maneira o compilador não iria conseguir ler o arquivo.
 * Certifique-se de não ter cometido erros ortográficos.
