---

# WOOO BANANAS

You did it! You created a function that takes input, processes that input, and provides output.

Run `javascripting` in the console to choose the next challenge.

---
