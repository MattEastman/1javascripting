---

# PERFECTO

Lo hiciste! Creaste una función que toma una entrada, procesa esa entrada y genera un resultado.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.
---
