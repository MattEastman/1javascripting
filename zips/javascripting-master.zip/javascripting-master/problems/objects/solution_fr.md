---

# L'OBJET PIZZA EST PRÊT.

Vous avez réussi à créer un objet !

Dans le prochain défi, nous nous focaliserons sur l'accès à des propriétés d'objets.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
