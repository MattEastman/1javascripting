---

# PIZZA OBJEKTET ER I ORDEN.

Du greide å lage et objekt!

I den neste oppgaven vil vi fokusere på å bruke objektets egenskaper.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
