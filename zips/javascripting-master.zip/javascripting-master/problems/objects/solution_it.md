---

# L'OGGETTO PIZZA È ANDATO.

Hai creato un oggetto con successo!

Nella prossima sfida ci occuperemo su come accedere alle proprietà degli oggetti.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
