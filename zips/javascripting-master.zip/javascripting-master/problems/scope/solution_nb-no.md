---

# UTMERKET!

Du skjønte det! Den andre funksjonen har det scopet vi lette etter.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
