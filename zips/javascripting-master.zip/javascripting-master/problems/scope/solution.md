---

#EXCELLENT!

You got it! The second function has the scope we were looking for.

Now move on to a more challenging Javascript workshopper **Functional Javascript**:

npm install -g functional-javascript-workshop

---
