---

# EXCELLENT !

C'est bon ! La seconde fonction possède le `scope` que nous recherchons.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
