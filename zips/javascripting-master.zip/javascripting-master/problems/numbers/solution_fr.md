---

# YEAH ! DES NOMBRES !

Génial ! Vous avez défini avec succès une variable contenant le nombre `123456789`.

Dans le prochain défi, nous nous intéresserons à la manipulation de nombres.

Exécutez `javascripting` dans la console pour choisir le prochain défi.

---
