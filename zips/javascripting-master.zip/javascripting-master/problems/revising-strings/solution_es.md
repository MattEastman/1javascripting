---

# SI, SEÑOR! LA PIZZA ES EXQUISITA

¡Bien hecho con ese método `replace`!

A continuación exploraremos los **números**.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
