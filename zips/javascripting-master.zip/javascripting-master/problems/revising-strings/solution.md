---

# YES, PIZZA _IS_ WONDERFUL.

Well done, with that `.replace()` method!

Next we will explore **numbers**.

Run `javascripting` in the console to choose the next challenge.

---
