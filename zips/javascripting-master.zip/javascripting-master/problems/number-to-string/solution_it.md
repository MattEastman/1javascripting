---

# THAT NUMBER IS NOW A STRING!

Excellent. Good work converting that number into a string.

In the next challenge we will take a look at **if statements**.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
