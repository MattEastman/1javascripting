---

# ESTE NÚMERO AGORA É UMA STRING!

Excelente! Você fez um bom trabalho convertendo o número em uma string.

No próximo desafio vamos ver como fazer condições usando **if**.

Execute `javascripting` no console para escolher o próximo desafio.

---
