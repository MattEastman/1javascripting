---

# CORRECTO! LOS HIPSTERS TIENEN SU PROPIO TIPO DE BICICLETAS

Buen trabajo accediendo a esa propiedad.

El siguiente ejercicio es completamente acerca de **funciones**.

Ejecuta `javascripting` en la consola para seleccionar el siguiente ejercicio.

---
