---

# CORRECT. PIZZA IS THE ONLY FOOD.

Good job accessing that property.

The next challenge is all about **functions**.

Run `javascripting` in the console to choose the next challenge.

---
