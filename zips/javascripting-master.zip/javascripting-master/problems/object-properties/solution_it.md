---

# CORRETTO. LA PIZZA È IL SOLO CIBO.

Ottimo lavoro nell'accedere a quella proprietà.

La prossima sfida è interamente centrata sulle **funzioni**.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
