---

# RIKTIG. PIZZA ER DEN ENESTE MATEN.

Bra jobba med å bruke den egenskapen.

Den neste oppgaven handler om **funksjoner**.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
