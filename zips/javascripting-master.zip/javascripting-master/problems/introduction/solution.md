---

# YOU DID IT!

Anything between the parentheses of `console.log()` are printed to the terminal.

So this: 

```js
console.log('hello');
```

prints `hello` to the terminal.

Currently we are printing a **string** of characters to the terminal: `hello`.

In the next challenge we focus on learning about **variables**.

Run `javascripting` in the console to choose the next challenge.
