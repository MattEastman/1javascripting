Um array é uma lista de valores. Aqui está um exemplo:

```js
var pets = ['cat', 'dog', 'rat'];
```

### Desafio:

Crie um arquivo chamado `arrays.js`.

No arquivo criado defina uma variável chamada `pizzaToppings` que referencia um array com três strings nesta ordem: `tomato sauce, cheese, pepperoni`.

Use o `console.log()` para imprimir o array `pizzaToppings` no terminal.

Verifique se o seu programa está correto executando este comando:

```bash
javascripting verify arrays.js
```
