---

# AEEEE! UM ARRAY DE PIZZAS!

Você criou um array com sucesso!

No próximo desafio veremos como filtrar os arrays.

Execute `javascripting` no console para escolher o próximo desafio.

---
