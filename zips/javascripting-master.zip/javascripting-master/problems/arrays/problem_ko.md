배열은 값의 목록입니다. 예를 들면 다음과 같습니다.

```js
var pets = ['cat', 'dog', 'rat'];
```

### 도전 과제

`arrays.js`라는 이름의 파일을 만듭니다.

이 파일에 `tomato sauce, cheese, pepperoni`의 순서대로 세 개의 문자열을 포함하는 배열을 참조하도록 `pizzaToppings`라는 변수를 선언합니다.

`console.log()`를 사용해 `pizzaToppings` 배열을 터미널에 출력합니다.

이 명령어를 실행해 프로그램이 올바른지 확인하세요.

```bash
javascripting verify arrays.js
```

