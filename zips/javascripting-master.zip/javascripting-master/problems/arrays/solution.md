---

# YAY, A PIZZA ARRAY!

You successfully created an array!

In the next challenge we will explore filtering arrays.

Run `javascripting` in the console to choose the next challenge.

---
