---

# HAI STAMPATO IL SECONDO ELEMENTO DELL'ARRAY!

Ottimo lavoro nell'accedere all'elemento dell'array.

Nella prossima sfida lavoreremo su un esempio di iterazione sugli elementi di un array.

Esegui `javascripting` nella console per scegliere la prossima sfida.

---
