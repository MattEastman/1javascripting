---

# DEN ANDRE VERDIEN AV ARRAYET SKREVET UT!

Godt jobba med å bruke den verdien i arrayet.

I den neste oppgaven skal vi jobbe med et eksempel på å bruke løkker på arrayer.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---