---

# FILTERED!

Good job filtering that array.

In the next challenge we will work on an example of accessing array values.

Run `javascripting` in the console to choose the next challenge.

---
