---

# FILTRERT!

Godt jobba med å filtrere det arrayet.

I den neste oppgaven skal vi jobbe med å lese verdiene i et array.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
