---

# THE TOTAL IS 45

That is a basic introduction to for loops, which are handy in a number of situations, particularly in combination with other data types like strings and arrays.

In the next challenge we'll start working with **arrays**.

Run `javascripting` in the console to choose the next challenge.

---
