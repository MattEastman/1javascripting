---

# NUMMERET ER AVRUNDET

Jepp, du avrundet nummeret `1.5` til `2`. Bra jobba!

I den neste oppgaven vil vi gjøre om et nummer til en string.

Kjør kommandoen `javascripting` i terminalen for å velge neste oppgave.

---
