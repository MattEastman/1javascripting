# You're doing fine!

Of course that's not all of existing inline tags, but these 5 is the most common used tags, so you definitely should know about them. Feel free to google about other tags. There are tags for different purposes like quoting, addressing, code, deletions and additions, keyboard keys and so on.

Nevertheless, we need to know how to make headings for dividing content by logical parts. That's what we are consider in following exercise.
