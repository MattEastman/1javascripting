module.exports = require('../../utils/problem')(__dirname);
