# Nice job!

So, you're familiar with HTML attributes. We have to say there is a lot of them, for different tags. You don't have to remember all of them - this will come to you with practice.

Let's summarize what you've already learned. You know what is HTML, you know what are tags, how attributes look like.

In the next exercise we are going to take a look at inline tags, which are usually used for styling text.
