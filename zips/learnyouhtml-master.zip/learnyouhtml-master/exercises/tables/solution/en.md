# Fine!

Here are few important notes about tables:

* You can put one table in a cell of other table.
* The table dimensions are not set initially. They are calculated based on the contents of the cells.
* If the table is given its width in percent or pixels, then the contents of the table are adjusted to the specified sizes.
* Browser doesn't display tables until they are loaded. That's because browser needs to calculate table's dimensions, before displaying.

In following exercise we will consider block tags and their semantic.
